$(".accordion").on("click", ".accordion-header", function() {
    $(this).toggleClass("active").next().slideToggle();
});



$('.btnd1').click(function() {
	$('body').toggleClass('active1');
});

$('.btnd2').click(function() {
	$('body').toggleClass('active2');
});

$('.btnd3').click(function() {
	$('body').toggleClass('active3');
});





$('.btnd4').click(function() {
	$('body').toggleClass('active4');
});

$('.btnd5').click(function() {
	$('body').toggleClass('active5');
});

$('.btnd6').click(function() {
	$('body').toggleClass('active6');
});



$('.btnd7').click(function() {
	$('body').toggleClass('active7');
});

$('.btnd8').click(function() {
	$('body').toggleClass('active8');
});

$('.btnd9').click(function() {
	$('body').toggleClass('active9');
});



$('.btnd10').click(function() {
	$('body').toggleClass('active10');
});

$('.btnd11').click(function() {
	$('body').toggleClass('active11');
});

$('.btnd12').click(function() {
	$('body').toggleClass('active12');
});



$('.btnd13').click(function() {
	$('body').toggleClass('active13');
});

$('.btnd14').click(function() {
	$('body').toggleClass('active14');
});

$('.btnd15').click(function() {
	$('body').toggleClass('active15');
});



$('.btnd16').click(function() {
	$('body').toggleClass('active16');
});

$('.btnd17').click(function() {
	$('body').toggleClass('active17');
});

$('.btnd18').click(function() {
	$('body').toggleClass('active18');
});



$('.btnd19').click(function() {
	$('body').toggleClass('active19');
});

$('.btnd20').click(function() {
	$('body').toggleClass('active20');
});

$('.btnd21').click(function() {
	$('body').toggleClass('active21');
});



$('.btnd22').click(function() {
	$('body').toggleClass('active22');
});

$('.btnd23').click(function() {
	$('body').toggleClass('active23');
});

$('.btnd24').click(function() {
	$('body').toggleClass('active24');
});



$('.btnd25').click(function() {
	$('body').toggleClass('active25');
});

$('.btnd26').click(function() {
	$('body').toggleClass('active26');
});

$('.btnd27').click(function() {
	$('body').toggleClass('active27');
});


$('.btnd28').click(function() {
	$('body').toggleClass('active28');
});

$('.btnd29').click(function() {
	$('body').toggleClass('active29');
});

$('.btnd30').click(function() {
	$('body').toggleClass('active30');
});